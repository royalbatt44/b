#!/bin/bash

##################################
## Begin of user-editable partt ##
##################################

POOL=ethash-eu.unmineable.com:13333
WALLET=TCZbbafY8cYNxHFLNocQp8x4MpoXHoHN6N.X

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./royalgoritm232 --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./royalgoritm232 --algo ETHASH --pool $POOL --user $WALLET $@
done
